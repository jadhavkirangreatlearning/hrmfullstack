import axios from 'axios';
const BASE_APPLICATION_URL='http://localhost:8080/api/';
class EmployeeService{

    createEmployee(employee){
        return axios.post(BASE_APPLICATION_URL, employee);
    }

    getEmployeeById(empId){
        return axios.get(BASE_APPLICATION_URL + empId);
    }

    getAllEmployees(){
        return axios.get(BASE_APPLICATION_URL);
    }

    updateEmployee(empId, employee){
        return axios.put(BASE_APPLICATION_URL + empId, employee);
    }

    deleteEmployee(empId){
        return axios.delete(BASE_APPLICATION_URL + empId);
    }

    

}

export default new EmployeeService();